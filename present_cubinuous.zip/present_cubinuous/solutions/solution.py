a = int(input())
b = int(input())
k = int(input())
ans = 2 * ((a + (k // 2) - 1) // (k // 2))
space = ans * k - 4 * a
b = max(0, b - space)
ans += (b + k - 1) // k
print(ans)
