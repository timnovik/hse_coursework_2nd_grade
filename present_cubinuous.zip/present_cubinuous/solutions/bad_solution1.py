a = int(input())
b = int(input())
k = int(input())
ans = (4 * a + b + k - 1) // k
print(ans)
