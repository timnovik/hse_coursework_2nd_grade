a = int(input())
b = int(input())
k = int(input())

n1 = (4 * a + b + k - 1) // k
n2 = (a + (k // 2) - 1) // (k // 2) * 2

print(max(n1, n2))

