a = int(input())
b = int(input())
k = int(input())

squares_vertical = k // 2
cond1 = 2 * ((a + (squares_vertical - 1)) // squares_vertical)
cond2 = (4 * a + b + (k - 1)) // k
print(max(cond1, cond2))
