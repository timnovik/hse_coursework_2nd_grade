#include "testlib.h"
 
using namespace std;
 
int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);
    int start = stoi(argv[1]);
    for (int i = start; i < start + 6; ++i) {
        startTest(i);
        int mx = (i < start + 2) ? 100 : 1e8;
        int a, b, k;
        int kmx = (i < start + 2) ? 9 : ((i < start + 4) ? 20 : 10000);
        if (i % 2) {
            k = 2 * rnd.next(1, kmx / 2 - 1) + 1;
        } else {
            k = 2 * rnd.next(1, kmx / 2);
        }
        a = rnd.next(0, mx * 9 / 10);
        int ans = (a + (k / 2) - 1) / (k / 2) * 2;
        int space = ans * k - 4 * a;
        while (space < k) {
            ++a;
            ans = (a + (k / 2) - 1) / (k / 2) * 2;
            space = ans * k - 4 * a;
        }
        b = rnd.next(0, space - k);
        cout << a << endl << b << endl << k << endl;
    }
 
    for (int i = start + 6; i < start + 13; ++i) {
        startTest(i);
        int mx = (i < start + 9) ? 100 : 1e8;
        int a, b, k;
        int kmx = (i < start + 9) ? 10 : ((i < start + 11) ? 20 : 10000);
        k = 2 * rnd.next(1, kmx / 2 - 1) + 1;
        a = (k / 2) * rnd.next(0, mx / (k / 2));
        int ans = (a + (k / 2) - 1) / (k / 2) * 2;
        int space = ans * k - 4 * a;
        b = rnd.next(0, space - k);
        cout << a << endl << b << endl << k << endl;
    }
 
    for (int i = start + 13; i < start + 19; ++i) {
        startTest(i);
        int mx = (i < start + 15) ? 100 : 1e8;
        int a, b, k;
        int kmx = (i < start + 15) ? 10 : ((i < start + 17) ? 20 : 10000);
        if (i % 2) {
            k = 2 * rnd.next(1, kmx / 2 - 1) + 1;
        } else {
            k = 2 * rnd.next(1, kmx / 2);
        }
        a = (k / 2) * rnd.next(0, mx / (k / 2));
        int ans = (a + (k / 2) - 1) / (k / 2) * 2;
        int space = ans * k - 4 * a;
        b = rnd.next(min(space, mx), mx);
        b -= (b - space) % k;
        cout << a << endl << b << endl << k << endl;
    }
    
    startTest(start + 19);
    cout <<(int)1e8 << endl << (int)1e8 << endl << 2 << endl;
}
