#include "testlib.h"

using namespace std;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);
    for (int i = 19; i <= 25; ++i) {
        startTest(i);
        cout << rnd.next(0, (int)1e8) << endl;
        cout << rnd.next(0, (int)1e8) << endl;
        cout << rnd.next(2, 100) << endl;
    }
}
