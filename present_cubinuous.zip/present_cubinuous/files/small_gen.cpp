#include "testlib.h"

using namespace std;

int main(int argc, char *argv[]) {
    registerGen(argc, argv, 1);
    for (int i = 6; i <= 10; ++i) {
        startTest(i);
        cout << rnd.next(0, 10) << endl;
        cout << rnd.next(0, 20) << endl;
        cout << rnd.next(2, 10) << endl;
    }
}
