#include <bits/stdc++.h>
#include "testlib.h"
 
using namespace std;
 
const int MAXGROUP = 2;
int LIMITS[] = {100'000'000, 100, 100'000'000};

int main(int argc, char *argv[]) {
    registerValidation(argc, argv);
    
    int group = (!validator.group().empty() ? stoi(validator.group()) : 0);
    ensuref(0 <= group && group <= MAXGROUP, "Incorrect group number");
    
    int a = inf.readInt(0, LIMITS[group], "a");
    inf.readEoln();
    int b = inf.readInt(0, LIMITS[group], "b");
    inf.readEoln();
    inf.readInt(2, LIMITS[group], "k");
    inf.readEoln();
    inf.readEof();
    ensuref(a + b > 0, "no squares");
}
